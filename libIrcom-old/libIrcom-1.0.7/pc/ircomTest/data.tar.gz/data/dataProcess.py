import re

fin = open("./data1.txt")

fout1 = open("distance.txt", 'w')
fout2 = open("direction.txt", 'w')
fout3 = open("sensorId.txt", 'w')

distance = []
direction = []
sensorId = []

find_re = re.compile('successful :.+?distance=(.+?) \t direction=(.+?) \t receivingSensor=(.+?)', re.DOTALL)

for line in fin:
    line = line.strip()
    if 'successful' in line:
        for x in find_re.findall(line):
            if x[2] == str(3) or x[2] == str(4): # assume sensor 0 and 7 are not in visual range
                distance.append(-2)
                direction.append(-2)
                sensorId.append(-2)
            else: # regular detection
                distance.append(x[0])
                direction.append(x[1])
                sensorId.append(x[2])
    elif 'failed' in line: # transmission error
        distance.append(-1)
        direction.append(-1)
        sensorId.append(-1)

for x in distance:
    fout1.write(str(x) + '\n')

for x in direction:
    fout2.write(str(x) + '\n')

for x in sensorId:
    fout3.write(str(x) + '\n')

fin.close()
fout1.close()
fout2.close()
fout3.close()
print("Done!")
    
